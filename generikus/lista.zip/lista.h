#ifndef LISTA_H
#define LISTA_H

/* duplan lancolt lista */
typedef struct ListaElem {
    struct ListaElem *elozo, *kovetkezo;
    void *adat;
} ListaElem;

/* ezek meg strazsak lesznek - kimelem magam */
typedef struct Lista {
    ListaElem *eleje, *vege;
} Lista;

/* ilyen alaku hasonlito fuggvenyt var a rendezo */
typedef int (*ListaElemHasonlito)(void const *, void const *);

void lista_uj(Lista *l);
void lista_felszabadit(Lista *l);
void lista_elejere(Lista *l, void *adat);
void lista_vegere(Lista *l, void *adat);
void lista_beszur(ListaElem *l, void *adat);
void lista_rendez(Lista *l, ListaElemHasonlito hasonlit);
void lista_mindegyiken(Lista *l, void (*fv)(void *));

#endif  /* LISTA_H */
