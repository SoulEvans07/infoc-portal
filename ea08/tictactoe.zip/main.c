#include <stdio.h>
#include <stdbool.h>
#include "jatekallas.h"
#include "megjelenites.h"

int main(void) {
    Jatek j1;
    jatek_uj(&j1, "Aladar", "Kriszta");

    /* 9 lépéssel megtelik a pálya */
    bool nyert;
    for (int i = 0; i < 9; ++i) {
        jatek_kirajzol(&j1);
        printf("%s lépése következik.\n", jatek_kovetkezo_neve(&j1));
        Pozicio p = pozicio_beolvas();
        nyert = jatek_lep(&j1, p);
        if (nyert)
            break;
    }
    if (nyert) {
        printf("Ezzel a lépéssel megnyerted!\n");
    } else {
        printf("Döntetlen.\n");
    }

    /* nincs hozzá menü, nem kidolgozott programrész.
     * csak a teszt kedvéért van itt. */
    jatek_ment(&j1, "tictactoe.txt");
    jatek_betolt(&j1, "tictactoe.txt");
    jatek_kirajzol(&j1);
}
