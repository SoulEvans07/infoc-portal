#include <stdio.h>
#include "megjelenites.h"

/**
 * Szabványos kimeneten megjeleníti a játékállást.
 */
void jatek_kirajzol(Jatek const *pj) {
    /* ebben a tömbben pont ugyanolyan sorrendben vannak, mint az enum értékei */
    static char const cella_kep[] = { ' ', 'o', 'x' };

    printf("+---+\n");
    for (int y = 0; y < 3; ++y) {
        printf("|");
        for (int x = 0; x < 3; ++x)
            printf("%c", cella_kep[pj->palya[y][x]]);
        printf("|\n");
    }
    printf("+---+\n");
}

/**
 * Beolvas a billentyűzetről egy "sor oszlop" pozíciót.
 * @return A beolvasott pozíció.
 */
Pozicio pozicio_beolvas(void) {
    Pozicio p;
    printf("Sor oszlop? ");
    scanf("%d %d", &p.y, &p.x);
    return p;
}
