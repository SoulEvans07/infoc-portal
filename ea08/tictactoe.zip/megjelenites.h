#ifndef MEGJELENITES_H
#define MEGJELENITES_H

#include "jatekallas.h"

void jatek_kirajzol(Jatek const *pj);
Pozicio pozicio_beolvas(void);

#endif
