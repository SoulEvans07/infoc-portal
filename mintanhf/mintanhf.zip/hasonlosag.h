#ifndef HASONLOSAG_H
#define HASONLOSAG_H

#include <stdio.h>
#include "dolgozat.h"

/* Struktúra, amely két dolgozat hasonlóságát tárolja. */
typedef struct Hasonlosag {
    Dolgozat *d1, *d2;                  /* melyik dolgozatok */
    double has;
} Hasonlosag;

Hasonlosag *hasonlit_osszes(Dolgozat *dolgozatok, int *phas_db);
void hasonlosag_rendez(Hasonlosag hasonlosagok[], int hasszam);
void hasonlosag_kepernyore(Hasonlosag h);
void hasonlosag_fajlba(Hasonlosag h, FILE *fp);

#endif
