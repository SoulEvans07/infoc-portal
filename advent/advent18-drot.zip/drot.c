#include <SDL2/SDL.h>
#include <SDL2/SDL2_gfxPrimitives.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include <stdbool.h>

Uint32 const szinek[] = { 0x000000FF, 0x008000FF, 0xFF0000FF, 0x0000FFFF, 0xFF00FFFF };
int const ABLAK_SZ = 640, ABLAK_M = 480;

typedef struct Pont {
    double x, y, z;     /* eredeti 3d koordináta */
    int hanyadik;       /* fájlbeli sorszám */

    double xf, yf, zf;  /* forgatott 3d koordináta */
    int xk, yk;         /* képernyőn koordináta */
    struct Pont *kov;
} Pont;

typedef struct Vonal {
    int pi1, pi2;   /* pontok indexe, amit osszekot */
    Pont *p1, *p2;  /* pointer rájuk, hogy ne kelljen mindig megkeresni */
    int szin;       /* színkód a fenti tömbből */
    struct Vonal *kov;
} Vonal;

typedef struct Szoveg {
    char felirat[100];  /* felirat szövege */
    int x, y, szin;     /* pozíció és szín */
    struct Szoveg *kov;
} Szoveg;

typedef struct Rajz {
    Pont *pontok;
    Vonal *vonalak;
    Szoveg *szovegek;
    bool latszik[5];    /* melyik színű vonalak látszanak épp */
} Rajz;


/* Beolvassa a fajlnev nevű fájlt a rajz inicializálatlan struktúrába.
 * Igazzal tér vissza, ha minden oké. */
bool beolvas(char const *fajlnev, Rajz *rajz) {
    /* inicializálás */
    rajz->latszik[0] = false;
    for (int i = 1; i < 5; ++i)
        rajz->latszik[i] = true;
    rajz->pontok = NULL;        /* üres listák */
    rajz->vonalak = NULL;
    rajz->szovegek = NULL;

    /* fájlból olvasás */
    FILE *fp = fopen(fajlnev, "rt");
    if (fp == NULL) {
        return false;
    }
    char sor[100];
    while (fgets(sor, sizeof(sor), fp)) {
        /* üres sort és kommentet szkippeljük */
        char tipus;
        if (sscanf(sor, " %c", &tipus)!=1 || tipus==';')
            continue;

        /* a sor első betűje mutatja a típust */
        switch (tolower(tipus)) {
            case 's':   /* szöveg */
                {
                    Szoveg *uj = (Szoveg *) malloc(sizeof(Szoveg));
                    sscanf(sor, " %*c %d %d %d %[^\r\n]", &uj->x, &uj->y, &uj->szin, uj->felirat);
                    uj->kov = rajz->szovegek;
                    rajz->szovegek = uj;
                }
                break;
            case 'p':   /* pont */
                {
                    Pont *uj = (Pont *) malloc(sizeof(Pont));
                    sscanf(sor, " %*c %d %lf %lf %lf", &uj->hanyadik, &uj->x, &uj->y, &uj->z);
                    uj->kov = rajz->pontok;
                    rajz->pontok = uj;
                }
                break;
            case 'l':   /* vonal két pont között */
                {
                    Vonal *uj = (Vonal *) malloc(sizeof(Vonal));
                    sscanf(sor, " %*c %d %d %d", &uj->szin, &uj->pi1, &uj->pi2);
                    uj->kov = rajz->vonalak;
                    rajz->vonalak = uj;
                }
                break;
        }
    }
    fclose(fp);

    /* megkeressük a vonalakhoz tartozó pontokat */
    for (Vonal *von = rajz->vonalak; von != NULL; von = von->kov) {
        Pont *iter;

        /* megkeressük a két pontot */
        for (iter = rajz->pontok; iter != NULL && iter->hanyadik != von->pi1; iter = iter->kov)
            ;   /* üres */
        if (iter == NULL)   /* hiányzik? */
            return false;
        von->p1 = iter;

        for (iter = rajz->pontok; iter != NULL && iter->hanyadik != von->pi2; iter = iter->kov)
            ;   /* üres */
        if (iter == NULL)   /* hiányzik? */
            return false;
        von->p2 = iter;
    }

    return true;
}


/* listák felszabadítása - láthatóan eléggé jól jönne egy generikus lista */
void rajz_felszabadit(Rajz *rajz) {
    while (rajz->vonalak) {
        Vonal *temp = rajz->vonalak->kov;
        free(rajz->vonalak);
        rajz->vonalak = temp;
    }
    while (rajz->pontok) {
        Pont *temp = rajz->pontok->kov;
        free(rajz->pontok);
        rajz->pontok = temp;
    }
    while (rajz->szovegek) {
        Szoveg *temp = rajz->szovegek->kov;
        free(rajz->szovegek);
        rajz->szovegek = temp;
    }
}

void forgat_es_vetit(SDL_Renderer *renderer, Rajz *rajz, double szog, double d) {
    /* beforgatás */
    for (Pont *pont = rajz->pontok; pont != NULL; pont = pont->kov) {
        /* forgatás: előbb x, aztán y, végül z tengely körül, aztán eltárolás */
        Pont fx = {pont->x, pont->y*cos(szog)-pont->z*sin(szog), pont->y*sin(szog)+pont->z*cos(szog)};
        Pont fy = {fx.x*cos(szog)-fx.z*sin(szog), fx.y, fx.x*sin(szog)+fx.z*cos(szog)};
        Pont fz = {fy.x*cos(szog)-fy.y*sin(szog), fy.x*sin(szog)+fy.y*cos(szog), fy.z};
        pont->xf = fz.x;
        pont->yf = fz.y;
        pont->zf = fz.z;
        /* perspektíva */
        pont->xk = +d * pont->xf/(pont->zf + d) + ABLAK_SZ/2;
        pont->yk = -d * pont->yf/(pont->zf + d) + ABLAK_M/2;
    }
}

void kirajzol(SDL_Renderer *renderer, Rajz const *rajz) {
    char felirat[]="0: szamok lathatosaga     1, 2, 3, 4: vonalak lathatosaga     ESC: kilep";

    /* rajzolás */
    boxColor(renderer, 0, 0, ABLAK_SZ - 1, ABLAK_M - 1, 0xFFFFFFFF);
    for (Szoveg *szov = rajz->szovegek; szov != NULL; szov = szov->kov) {
        stringColor(renderer, szov->x, szov->y, szov->felirat, szinek[szov->szin]);
    }
    for (Vonal *von = rajz->vonalak; von != NULL; von = von->kov) {
        if (rajz->latszik[von->szin]) {
            aalineColor(renderer, von->p1->xk, von->p1->yk, von->p2->xk, von->p2->yk, szinek[von->szin]);
            aalineColor(renderer, von->p1->xk, von->p1->yk+1, von->p2->xk, von->p2->yk+1, szinek[von->szin]); /* vastagít */
        }
    }
    /* a 0-s láthatóság a pontok sorszámait mutatja */
    if (rajz->latszik[0])
        for (Pont *pont = rajz->pontok; pont != NULL; pont = pont->kov) {
            char s[10];
            int hossz = sprintf(s, "%d", pont->hanyadik);
            stringColor(renderer, pont->xk - hossz*4, pont->yk - 4, s, szinek[0]);
        }

    stringColor(renderer, (ABLAK_SZ - strlen(felirat)*8)/2, ABLAK_M-10, felirat, szinek[0]);
    SDL_RenderPresent(renderer);
}


Uint32 idozit(Uint32 ms, void* param) {
    SDL_Event ev;
    ev.type = SDL_USEREVENT;
    SDL_PushEvent(&ev);
    return ms;   /* ujabb varakozas */
}


int main(int argc, char *argv[]) {
    Rajz rajz;
    if (!beolvas(argv[1] ? argv[1] : "foci.3d", &rajz)) {
        fprintf(stderr, "Nem lehet megnyitni a fajlt\n");
        return 1;
    }

    /* SDL inicializálása és ablak megnyitása */
    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER);
    SDL_Window *window = SDL_CreateWindow("Drotvaz 3D", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, ABLAK_SZ, ABLAK_M, 0);
    if (window == NULL) {
        SDL_Log("Nem hozhato letre az ablak: %s", SDL_GetError());
        exit(1);
    }
    SDL_Renderer *renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_SOFTWARE);
    if (renderer == NULL) {
        SDL_Log("Nem hozhato letre a megjelenito: %s", SDL_GetError());
        exit(1);
    }

    SDL_TimerID id = SDL_AddTimer(40, idozit, NULL);
    bool kilep = false;
    /* eseményhurok */
    double szog = 0.3;
    double d = 800;
    while (!kilep) {
        SDL_Event event;
        SDL_WaitEvent(&event);

        switch (event.type) {
            case SDL_KEYDOWN:
                switch (event.key.keysym.sym) {
                    case SDLK_0: rajz.latszik[0] = !rajz.latszik[0]; break;
                    case SDLK_1: rajz.latszik[1] = !rajz.latszik[1]; break;
                    case SDLK_2: rajz.latszik[2] = !rajz.latszik[2]; break;
                    case SDLK_3: rajz.latszik[3] = !rajz.latszik[3]; break;
                    case SDLK_4: rajz.latszik[4] = !rajz.latszik[4]; break;
                    case SDLK_UP: if (d>=200) d -= 25; break;
                    case SDLK_DOWN: d += 25; break;
                    case SDLK_ESCAPE: kilep = true; break;
                    default: break;
                }
                break;
            case SDL_USEREVENT:
                forgat_es_vetit(renderer, &rajz, szog, d);
                kirajzol(renderer, &rajz);
                szog += 0.01;
                break;
            case SDL_QUIT:
                kilep = true;
                break;
        }
    }
    SDL_RemoveTimer(id);

    rajz_felszabadit(&rajz);

    SDL_Quit();

    return 0;
}
