#include <SDL2/SDL.h>
#include <SDL2/SDL2_gfxPrimitives.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "widget.h"


/* itt lehet állítgatni a színeket */
static unsigned long const hatter = 0x303030FF;
static unsigned long const keret = 0x000000FF;
static unsigned long const alapszin = 0x101010FF;
static unsigned long const keretvilagos = 0xFFFFFF20;
static unsigned long const gombfeliratszin = 0x00C0F0FF;
static unsigned long const csuszkaszin = 0x00FFFF50;
static unsigned long const feliratszin = 0x00C0F0FF;


/* mindenki hasznalja */
SDL_Renderer *renderer;

/* a megadott billentyuzet callback fuggvenye es parametere. ez hivodik
 * akkor, amikor az esemenyvezerelt_main billentyulenyomast erzekel. */
static void (*billentyuzet_cb_fv) (SDL_KeyboardEvent *, void *) = NULL;
static void *billentyuzet_cb_param = NULL;


/* egy widget kirajzolasa, altalanossagban. egy keretet ad csak. */
/* a keret tulnyulik az aktiv (kattinthato) mereten. */
void widget_alap_rajzol(Widget *widget) {
    roundedRectangleColor(renderer, widget->x - 1, widget->y - 1, widget->x + widget->szeles,
                          widget->y + widget->magas, 2, keret);
    boxColor(renderer, widget->x, widget->y, widget->x + widget->szeles - 1,
             widget->y + widget->magas - 1, alapszin);
    for (int y = 0; y < 20; ++y) {
        boxRGBA(renderer, widget->x, widget->y + y * widget->magas / 20,
                widget->x + widget->szeles - 1, widget->y + (y + 1) * widget->magas / 20 - 1, 255,
                255, 255, (19 - y) * 3);
    }
    rectangleColor(renderer, widget->x, widget->y, widget->x + widget->szeles - 1,
                   widget->y + widget->magas - 1, keretvilagos);
}


/* letrehoz egy uj, egyelore ismeretlen tipusu widgetet. tulajdonkepp csak a helyet allitja be */
Widget *uj_widget(int x, int y, int szeles, int magas) {
    Widget *uj = (Widget *) malloc(sizeof(Widget));
    uj->tipus = altalanos;
    uj->x = x;
    uj->y = y;
    uj->szeles = szeles;
    uj->magas = magas;
    uj->rajzolo_fv = widget_alap_rajzol;
    uj->kattintas_fv = NULL;
    uj->felhasznaloi_cb = NULL;
    uj->felhasznaloi_cb_param = NULL;
    return uj;
}


/* kirajzolja a gombot. keret, alapszin, felirat. */
static void gomb_rajzol(Widget *gomb) {
    widget_alap_rajzol(gomb);
    stringColor(renderer, gomb->x + (gomb->szeles - strlen(gomb->adat.gomb.felirat) * 8) / 2,
                gomb->y + (gomb->magas - 8) / 2, gomb->adat.gomb.felirat, gombfeliratszin);
}


/* gombot hoz letre. */
Widget *uj_gomb(int x, int y, int szeles, int magas, char const *felirat) {
    Widget *uj = uj_widget(x, y, szeles, magas);
    uj->tipus = gomb;
    uj->rajzolo_fv = gomb_rajzol;
    strcpy(uj->adat.gomb.felirat, felirat);
    return uj;
}


/* kirajzol egy feliratot. nem hivodik az alap rajzolo, mert nem kell neki keret! */
static void felirat_rajzol(Widget *felirat) {
    stringColor(renderer, felirat->x, felirat->y, felirat->adat.felirat.szoveg, feliratszin);
}


/* feliratot hoz letre. */
Widget *uj_felirat(int x, int y, char const *szoveg) {
    Widget *uj = uj_widget(x, y, 0, 0);
    uj->tipus = felirat;
    uj->rajzolo_fv = felirat_rajzol;
    strcpy(uj->adat.felirat.szoveg, szoveg);
    return uj;
}


/* csuszkaot rajzol; a keretet meghagyja, de belul mindent
 * felulir a sajat szinevel */
static void csuszka_rajzol(Widget *csuszka) {
    widget_alap_rajzol(csuszka);
    boxColor(renderer, csuszka->x, csuszka->y,
             csuszka->x + csuszka->szeles * csuszka->adat.csuszka.jelenlegi,
             csuszka->y + csuszka->magas - 1, csuszkaszin);
}


/* ez a sajat adatfeldolgozoja; nem kulon hozzaadott, hanem elvalaszthatatlan */
static void csuszka_kattintas(Widget *csuszka, int x, int y) {
    csuszka->adat.csuszka.jelenlegi = (double) x / (csuszka->szeles);
    csuszka_rajzol(csuszka);
}


/* csuszkat hoz letre */
Widget *uj_csuszka(int x, int y, int szeles, int magas, double kezdeti) {
    Widget *uj = uj_widget(x, y, szeles, magas);
    uj->tipus = csuszka;
    uj->rajzolo_fv = csuszka_rajzol;
    uj->kattintas_fv = csuszka_kattintas;
    uj->adat.csuszka.jelenlegi = kezdeti;
    return uj;
}


/* az esemenyhurok kirajzolja a widgeteket, es feldolgozza a felhasznalotol erkezo
 * esemenyeket (eger kattintasok es ablak bezarasa.) */
void esemenyvezerelt_main(Widget *widgetek[]) {
    /* azzal kezdjuk, hogy mindent kirajzolunk */
    SDL_SetRenderDrawColor(renderer, (hatter & 0xFF000000) >> 6, (hatter & 0x00FF0000) >> 4, (hatter & 0x0000FF00) >> 2, (hatter & 0x000000FF));
    SDL_RenderClear(renderer);
    for (int i = 0; widgetek[i] != NULL; i++)
        widgetek[i]->rajzolo_fv(widgetek[i]);
    SDL_RenderPresent(renderer);

    /* esemenyhurok */
    bool vege = false;
    while (!vege) {
        SDL_Event ev;
        SDL_WaitEvent(&ev);

        switch (ev.type) {
        case SDL_QUIT:
            vege = true;
            break;

        case SDL_MOUSEBUTTONUP:
            for (int i = 0; widgetek[i] != NULL; i++) {
                /* ennek a widgetnek a teruletere kattintott? */
                if (ev.button.x >= widgetek[i]->x && ev.button.y >= widgetek[i]->y
                    && ev.button.x < widgetek[i]->x + widgetek[i]->szeles
                    && ev.button.y < widgetek[i]->y + widgetek[i]->magas) {
                    /* widget-relativ kattintas koordinatak */
                    int bx = ev.button.x - widgetek[i]->x;
                    int by = ev.button.y - widgetek[i]->y;
                    /* widgetek belso mukodese */
                    if (widgetek[i]->kattintas_fv != NULL)
                        widgetek[i]->kattintas_fv(widgetek[i], bx, bx);
                    /* esetleg tarsitott callback */
                    if (widgetek[i]->felhasznaloi_cb != NULL)
                        widgetek[i]->felhasznaloi_cb(widgetek[i], bx, by,
                                                     widgetek[i]->felhasznaloi_cb_param);
                }
            }
            SDL_RenderPresent(renderer);   /* tortenhettek valtozasok, rajzolas */
            break;

        case SDL_KEYDOWN:
        case SDL_KEYUP:
            /* ha van megadva billentyuzet callback, meghivja */
            if (billentyuzet_cb_fv != NULL)
                billentyuzet_cb_fv(&ev.key, billentyuzet_cb_param);
            break;
        }
    }
}


/* a gomb rakattintva general egy szintetikus SDL_QUIT esemenyt.
 * barmely alkalmazas hasznalhatja kilepes gombnak */
void kilep_gomb_cb(Widget *widget, int x, int y, void *param) {
    SDL_Event ev = { SDL_QUIT };
    SDL_PushEvent(&ev);
}


/* inicializalja a widgetes dolgokat */
void widget_init(char *ablaknev, int w, int h) {
    SDL_Window *window = SDL_CreateWindow(ablaknev, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, w, h, 0);
    if (window == NULL) {
        SDL_Log("Nem hozhato letre az ablak: %s", SDL_GetError());
        exit(1);
    }
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_SOFTWARE);
    if (renderer == NULL) {
        SDL_Log("Nem hozhato letre a megjelenito: %s", SDL_GetError());
        exit(1);
    }
}


/* megjegyzi az adott fuggveny+parameter parost billentyuzet esemenykor hivandonak. */
void billentyuzet_cb_megad(void (*cb) (SDL_KeyboardEvent *, void *), void *param) {
    billentyuzet_cb_fv = cb;
    billentyuzet_cb_param = param;
}
