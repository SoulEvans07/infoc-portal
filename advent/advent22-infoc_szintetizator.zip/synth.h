#ifndef SYNTH_H
#define SYNTH_H

#include <stdbool.h>

typedef enum HangAllapot {
    csend, felfutas, lecsenges, tartas, elengedes
} HangAllapot;


typedef struct Hang {
    SDL_Keycode sym;                 /* billentyuje */
    double frek;                /* a frekvenciaja */

    double hangero;             /* a hangero, 0->1 és 1->0 valtoztatva, hogy ne pattogjon */
    bool szol;                  /* billentyu lenyomva? */
    HangAllapot all;            /* aktualis allapot a burkologorbehez */
} Hang;


typedef struct HangSzin {
    double felfutas_ido;        /* masodperc */
    double lecsenges_ido;       /* masodperc */
    double tartas_hangero;      /* arany 1-hez kepest */
    double elengedes_ido;       /* masodperc */
    struct Harmonikus {
        char *nev;              /* a neve */
        double frekszorzo;      /* hanyszoros frekvencia az alaphanghoz kepest */
        double arany;           /* mekkora hangerovel */
    } felharm[10];              /* felharmonikusok. 0-dik nem hasznalt, 1-es az alap. */

    double amplmod_frek, amplmod_ampl;
    double fazis_mod_frek, fazis_mod_ampl;
} HangSzin;


typedef struct Szinti {
    double hangero;
    HangSzin *hangszin;
    Hang *hangok;
} Szinti;


void hang_init(Szinti *szinti);
void hang_start(void);
void hang_stop(void);


#endif
