#include <SDL2/SDL.h>
#include <SDL2/SDL2_gfxPrimitives.h>
#include "widget.h"
#include "synth.h"


/* ahhoz a csuszkahoz, amelyik valtozas eseten rogton atallitja
 * a double valtozot, amire hivatkozik. */
static void set_double(Widget *widget, int x, int y, void *param) {
    double *cel = (double *) param;
    *cel = widget->adat.csuszka.jelenlegi;
}


/* olyan double csuszkat hoz letre, amire kattinta valahol egy double
 * valtozo beallitodik. a kezdeti ertek a valtozo alapjan lesz. */
static Widget *uj_double_csuszka(int x, int y, int szel, int mag, double *pd) {
    Widget *w = uj_csuszka(x, y, szel, mag, *pd);
    w->felhasznaloi_cb = set_double;
    w->felhasznaloi_cb_param = (void *) pd;
    return w;
}


/* ezt hivja meg az esemenyvezerelt foprogram billentyuzet eseten.
 * az egeret lekezeli maga. */
static void billentyuzet_kezel(SDL_KeyboardEvent * keyevent, void *param) {
    Hang *hangok = (Hang *) param;

    /* magzar billentzűyet miatt */
    if (keyevent->keysym.sym == SDLK_z)
        keyevent->keysym.sym = SDLK_y;
    for (int i = 0; hangok[i].sym != SDLK_UNKNOWN; ++i)
        /* ehhez a hanghoz tartozik? */
        if (keyevent->keysym.sym == hangok[i].sym)
            hangok[i].szol = keyevent->type == SDL_KEYDOWN;
}


/* zongora tipusu widget rajzolo fuggvenye. altalanos widgetnek
 * van megjelolve, az esemenykezelo nem nagyon foglalkozik vele. */
static void zongorat_rajzol(Widget *w) {
    double sizx = w->szeles / 8.0, sizy = w->magas / 5.05;

    widget_alap_rajzol(w);

    for (int i = 0; i < 8; ++i) {
        boxColor(renderer, w->x + i * sizx, w->y, w->x + (i + 1) * sizx - 1, w->y + 5 * sizy,
                 0xFFFFFFC0);
        rectangleColor(renderer, w->x + i * sizx, w->y, w->x + (i + 1) * sizx - 1, w->y + 5 * sizy,
                       0x000000FF);
        characterColor(renderer, w->x + i * sizx + (sizx - 8) / 2, w->y + 5 * sizy - 12,
                       "QWERTYUI"[i], 0x000000FF);
    }
    for (int i = 0; i < 6; ++i) {
        if (i == 2)
            continue;
        boxColor(renderer, w->x + (i + 1) * sizx - 1 - sizx / 3, w->y + 0,
                 w->x + (i + 1) * sizx - 1 + sizx / 3, w->y + 3.5 * sizy, 0x000000FF);
        characterColor(renderer, w->x + (i + 1) * sizx - 1 - sizx / 3 + (2 * sizx / 3 - 8) / 2,
                       w->y + 3.5 * sizy - 12, "234567"[i], 0xC0C0C0FF);
    }
}


/* zongora widget letrehozasa. */
Widget *uj_zongora(int x, int y, int szeles, int magas) {
    Widget *z = uj_widget(x, y, szeles, magas);
    z->rajzolo_fv = zongorat_rajzol;
    return z;
}


/* kiirja az aktualis beallitasokat a kepernyore. */
static void szinti_adatait_kiir(Widget *widget, int x, int y, void *param) {
    Szinti *sz = (Szinti *) param;

    printf("Jelenlegi beallitasok:\n");
    printf("  Felfutas: %g s\n", sz->hangszin->felfutas_ido);
    printf("  Lecsenges: %g s\n", sz->hangszin->lecsenges_ido);
    printf("  Tartas: %g %%\n", sz->hangszin->tartas_hangero * 100);
    printf("  Elengedes: %g s\n", sz->hangszin->elengedes_ido);
    printf("  Amplitudo modulacio frekvencia: %g Hz\n", sz->hangszin->amplmod_frek * 25);
    printf("  Amplitudo modulacio amplitudo: %g %%\n", sz->hangszin->amplmod_ampl * 100);
    printf("  Fazis modulacio frekvencia: %g Hz\n", sz->hangszin->fazis_mod_frek * 25);
    printf("  Fazis modulacio amplitudo: %g rad\n", sz->hangszin->fazis_mod_ampl * 2);

    for (int i = 0; sz->hangszin->felharm[i].frekszorzo != 0; ++i)
        printf("  %gx harmonikus: %g\n", sz->hangszin->felharm[i].frekszorzo,
               sz->hangszin->felharm[i].arany);
    printf("\n");
}


int main(int argc, char *argv[]) {
    /* A szintetizator dolgai */
    Hang hangok[] = {
        { SDLK_q, 440.0 * pow(2, -9 * 1.0/12.0) },   /* C */
        { SDLK_2, 440.0 * pow(2, -8 * 1.0/12.0) },   /* C# */
        { SDLK_w, 440.0 * pow(2, -7 * 1.0/12.0) },   /* D */
        { SDLK_3, 440.0 * pow(2, -6 * 1.0/12.0) },   /* D# */
        { SDLK_e, 440.0 * pow(2, -5 * 1.0/12.0) },   /* E */
        { SDLK_r, 440.0 * pow(2, -4 * 1.0/12.0) },   /* F */
        { SDLK_5, 440.0 * pow(2, -3 * 1.0/12.0) },   /* F# */
        { SDLK_t, 440.0 * pow(2, -2 * 1.0/12.0) },   /* G */
        { SDLK_6, 440.0 * pow(2, -1 * 1.0/12.0) },   /* G# */
        { SDLK_y, 440.0 * pow(2,  0 * 1.0/12.0) },   /* A */
        { SDLK_7, 440.0 * pow(2,  1 * 1.0/12.0) },   /* A# */
        { SDLK_u, 440.0 * pow(2,  2 * 1.0/12.0) },   /* H */
        { SDLK_i, 440.0 * pow(2,  3 * 1.0/12.0) },   /* C' */
        { SDLK_UNKNOWN }    /* tomb veget jeloli */
    };
    HangSzin hsz = {
        0.025, 0.025, 0.5, 0.1,   /* adsr */
        {{"16' harm.", 0.5, 0.3}, /* felharmonikusok */
         {"5 1/3' harm.", 0.66, 0.5},
         {"8' (alap) harm.", 1, 0.7},
         {"4' harm.", 2, 0.5},
         {"2 2/3' harm.", 3, 0},
         {"2' harm.", 4, 0},
         {"1 3/5' harm.", 5, 0},
         {"1 1/3' harm.", 6, 0},
         {"1' harm.", 8, 0},
         {NULL, 0}},
        0.2, 0.1,                 /* amplmod = tremolo */
        0.2, 0.2,                 /* fazismod = vibrato */
    };
    Szinti sz = { 2048, &hsz, hangok }; /* master volumne; hangszin; hangok */

    /* user interface dolgai */
    Widget *widgetek[40], *gomb;


    /* SDL es a sajat konyvtaraink inicializalasa */
    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_TIMER);
    widget_init("InfoC Szintetizator", 560, 480);
    hang_init(&sz);

    /* a felhasznaloi felulet megepitese - a widgetek letrehozasa */
    int db = 0;
    widgetek[db++] = uj_zongora(130, 20, 300, 100);

    /* mekkora sorminta */
    widgetek[db++] = uj_felirat(20, 150, "felfutas (s)");
    widgetek[db++] = uj_double_csuszka(150, 144, 100, 20, &hsz.felfutas_ido);
    widgetek[db++] = uj_felirat(20, 180, "lecsenges (s)");
    widgetek[db++] = uj_double_csuszka(150, 174, 100, 20, &hsz.lecsenges_ido);
    widgetek[db++] = uj_felirat(20, 210, "tartas (%)");
    widgetek[db++] = uj_double_csuszka(150, 204, 100, 20, &hsz.tartas_hangero);
    widgetek[db++] = uj_felirat(20, 240, "elengedes (s)");
    widgetek[db++] = uj_double_csuszka(150, 234, 100, 20, &hsz.elengedes_ido);
    widgetek[db++] = uj_felirat(20, 300, "tremolo f (Hz)");
    widgetek[db++] = uj_double_csuszka(150, 294, 100, 20, &hsz.amplmod_frek);
    widgetek[db++] = uj_felirat(20, 330, "tremolo A (%)");
    widgetek[db++] = uj_double_csuszka(150, 324, 100, 20, &hsz.amplmod_ampl);
    widgetek[db++] = uj_felirat(20, 360, "vibrato f (Hz)");
    widgetek[db++] = uj_double_csuszka(150, 354, 100, 20, &hsz.fazis_mod_frek);
    widgetek[db++] = uj_felirat(20, 390, "vibrato A (rad)");
    widgetek[db++] = uj_double_csuszka(150, 384, 100, 20, &hsz.fazis_mod_ampl);

    for (int i = 0; hsz.felharm[i].frekszorzo != 0; ++i) {
        widgetek[db++] = uj_felirat(300, i * 30 + 150, hsz.felharm[i].nev);
        widgetek[db++] = uj_double_csuszka(440, i * 30 + 150 - 6, 100, 20, &hsz.felharm[i].arany);
    }

    widgetek[db++] = gomb = uj_gomb(120, 440, 100, 20, "adatok");
    gomb->felhasznaloi_cb = szinti_adatait_kiir;
    gomb->felhasznaloi_cb_param = &sz;

    widgetek[db++] = gomb = uj_gomb(360, 440, 100, 20, "kilep");
    gomb->felhasznaloi_cb = kilep_gomb_cb;

    widgetek[db] = NULL;        /* lezaro elem */

    /* atadjuk a toolkitnek a billentyuzetkezelonket is */
    billentyuzet_cb_megad(billentyuzet_kezel, (void *) hangok);


    /* hang indiasa es belepes az esemenyvezerelt hurokba */
    hang_start();
    esemenyvezerelt_main(widgetek);
    hang_stop();

    for (int i = 0; widgetek[i] != NULL; ++i)
        free(widgetek[i]);

    return 0;
}
