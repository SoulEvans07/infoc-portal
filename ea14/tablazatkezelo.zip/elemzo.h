#ifndef ELEMZO_H
#define ELEMZO_H

#include <stdbool.h>
#include "tablazat.h"

bool kiertekel(char *szoveg, double *ertek, tablazat *a_tablazat);

#endif /* ELEMZO_H */
